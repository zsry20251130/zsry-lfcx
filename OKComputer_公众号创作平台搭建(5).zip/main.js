// 创作平台主要交互逻辑
class CreativePlatform {
    constructor() {
        this.currentFilter = 'all';
        this.works = this.initializeWorks();
        this.donationData = this.initializeDonationData();
        this.readingProgress = JSON.parse(localStorage.getItem('readingProgress') || '{}');
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initializeAnimations();
        this.loadWorks();
        this.updateDonationStats();
        this.initializeParticleBackground();
    }

    initializeWorks() {
        return [
            {
                id: 1,
                title: "城市的温度",
                type: "novel",
                category: "小说",
                description: "一个关于都市生活的温情故事，探索现代人在钢筋水泥森林中寻找温暖的旅程。",
                cover: "resources/book-cover-1.png",
                status: "连载中",
                chapters: 12,
                totalChapters: 20,
                tags: ["都市", "温情", "成长"],
                publishDate: "2024-10-15",
                readCount: 1234,
                content: "在这个快节奏的都市里，每个人都在为自己的梦想奔波。林晓是一名普通的白领，每天穿梭在地铁和高楼大厦之间..."
            },
            {
                id: 2,
                title: "时光邮局",
                type: "essay",
                category: "散文",
                description: "通过书信的形式，记录生活中的点点滴滴，感受时间在文字中流淌的美好。",
                cover: "resources/book-collection.png",
                status: "已完结",
                chapters: 8,
                totalChapters: 8,
                tags: ["书信", "生活", "时光"],
                publishDate: "2024-09-20",
                readCount: 856,
                content: "亲爱的时光：当我提笔写下这封信的时候，窗外的梧桐叶正在秋风中轻轻摇曳..."
            },
            {
                id: 3,
                title: "星空下的诗",
                type: "poetry",
                category: "诗歌",
                description: "在宁静的夜晚，仰望星空，用文字记录内心的感悟和对宇宙的思考。",
                cover: "resources/reading-corner.png",
                status: "连载中",
                chapters: 15,
                totalChapters: 30,
                tags: ["诗歌", "星空", "哲思"],
                publishDate: "2024-11-01",
                readCount: 642,
                content: "繁星点点，
如钻石般镶嵌在夜的帷幕上。
每一颗星星，
都是一个遥远的世界，
承载着无数的故事..."
            },
            {
                id: 4,
                title: "雨巷漫步",
                type: "novel",
                category: "小说",
                description: "在江南的雨巷中，两个陌生人的偶遇，展开了一段跨越时空的情感纠葛。",
                cover: "resources/hero-writing-desk.png",
                status: "连载中",
                chapters: 6,
                totalChapters: 15,
                tags: ["江南", "爱情", "时空"],
                publishDate: "2024-11-10",
                readCount: 987,
                content: "雨，细细密密地下着，像是天空在诉说着什么。青石板路上，一把油纸伞下，她静静地走着..."
            }
        ];
    }

    initializeDonationData() {
        return {
            totalAmount: 2580,
            totalSupporters: 156,
            monthlyAmount: 320,
            recentDonations: [
                { name: "文学爱好者", amount: 20, message: "很喜欢你的文字，继续加油！", date: "2024-11-28" },
                { name: "小雨", amount: 10, message: "《时光邮局》让我很感动", date: "2024-11-27" },
                { name: "书虫一枚", amount: 50, message: "支持你创作更多好作品", date: "2024-11-26" },
                { name: "夜读人", amount: 15, message: "期待新章节", date: "2024-11-25" },
                { name: "梦想家", amount: 30, message: "文字很有温度", date: "2024-11-24" }
            ]
        };
    }

    setupEventListeners() {
        // 作品筛选器
        const filterButtons = document.querySelectorAll('.filter-btn');
        filterButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.filterWorks(e.target.dataset.filter);
            });
        });

        // 搜索功能
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.searchWorks(e.target.value);
            });
        }

        // 打赏按钮
        const donateButtons = document.querySelectorAll('.donate-btn');
        donateButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                this.showDonationModal();
            });
        });

        // 打赏模态框
        const modal = document.getElementById('donationModal');
        const closeModal = document.querySelector('.close-modal');
        if (closeModal) {
            closeModal.addEventListener('click', () => {
                modal.style.display = 'none';
            });
        }

        // 打赏金额选择
        const amountButtons = document.querySelectorAll('.amount-btn');
        amountButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.selectDonationAmount(e.target.dataset.amount);
            });
        });

        // 确认打赏
        const confirmDonate = document.getElementById('confirmDonate');
        if (confirmDonate) {
            confirmDonate.addEventListener('click', () => {
                this.processDonation();
            });
        }
    }

    initializeAnimations() {
        // 标题文字动画
        const titles = document.querySelectorAll('.animate-title');
        titles.forEach(title => {
            anime({
                targets: title,
                opacity: [0, 1],
                translateY: [30, 0],
                duration: 1000,
                delay: anime.stagger(200),
                easing: 'easeOutExpo'
            });
        });

        // 卡片悬停动画
        const cards = document.querySelectorAll('.work-card');
        cards.forEach(card => {
            card.addEventListener('mouseenter', () => {
                anime({
                    targets: card,
                    scale: 1.05,
                    rotateY: 5,
                    duration: 300,
                    easing: 'easeOutQuad'
                });
            });

            card.addEventListener('mouseleave', () => {
                anime({
                    targets: card,
                    scale: 1,
                    rotateY: 0,
                    duration: 300,
                    easing: 'easeOutQuad'
                });
            });
        });
    }

    initializeParticleBackground() {
        if (typeof p5 !== 'undefined') {
            new p5((sketch) => {
                let particles = [];
                
                sketch.setup = () => {
                    const canvas = sketch.createCanvas(sketch.windowWidth, sketch.windowHeight);
                    canvas.parent('particle-background');
                    canvas.style('position', 'fixed');
                    canvas.style('top', '0');
                    canvas.style('left', '0');
                    canvas.style('z-index', '-1');
                    
                    for (let i = 0; i < 50; i++) {
                        particles.push({
                            x: sketch.random(sketch.width),
                            y: sketch.random(sketch.height),
                            vx: sketch.random(-0.5, 0.5),
                            vy: sketch.random(-0.5, 0.5),
                            size: sketch.random(2, 4)
                        });
                    }
                };
                
                sketch.draw = () => {
                    sketch.clear();
                    
                    particles.forEach(particle => {
                        sketch.fill(212, 165, 116, 30);
                        sketch.noStroke();
                        sketch.circle(particle.x, particle.y, particle.size);
                        
                        particle.x += particle.vx;
                        particle.y += particle.vy;
                        
                        if (particle.x < 0 || particle.x > sketch.width) particle.vx *= -1;
                        if (particle.y < 0 || particle.y > sketch.height) particle.vy *= -1;
                    });
                };
                
                sketch.windowResized = () => {
                    sketch.resizeCanvas(sketch.windowWidth, sketch.windowHeight);
                };
            });
        }
    }

    filterWorks(filter) {
        this.currentFilter = filter;
        
        // 更新按钮状态
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-filter="${filter}"]`).classList.add('active');
        
        // 筛选作品
        this.loadWorks();
    }

    searchWorks(keyword) {
        const filteredWorks = this.works.filter(work => 
            work.title.toLowerCase().includes(keyword.toLowerCase()) ||
            work.description.toLowerCase().includes(keyword.toLowerCase()) ||
            work.tags.some(tag => tag.toLowerCase().includes(keyword.toLowerCase()))
        );
        
        this.displayWorks(filteredWorks);
    }

    loadWorks() {
        let filteredWorks = this.works;
        
        if (this.currentFilter !== 'all') {
            filteredWorks = this.works.filter(work => work.type === this.currentFilter);
        }
        
        this.displayWorks(filteredWorks);
    }

    displayWorks(works) {
        const container = document.getElementById('worksContainer');
        if (!container) return;
        
        container.innerHTML = '';
        
        works.forEach(work => {
            const workCard = this.createWorkCard(work);
            container.appendChild(workCard);
        });
        
        // 添加动画
        anime({
            targets: '.work-card',
            opacity: [0, 1],
            translateY: [20, 0],
            duration: 600,
            delay: anime.stagger(100),
            easing: 'easeOutExpo'
        });
    }

    createWorkCard(work) {
        const card = document.createElement('div');
        card.className = 'work-card bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 cursor-pointer';
        
        const progress = this.readingProgress[work.id] || 0;
        const progressPercentage = (progress / work.totalChapters) * 100;
        
        card.innerHTML = `
            <div class="relative">
                <img src="${work.cover}" alt="${work.title}" class="w-full h-48 object-cover">
                <div class="absolute top-2 right-2">
                    <span class="px-2 py-1 text-xs font-medium rounded-full ${work.status === '连载中' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'}">
                        ${work.status}
                    </span>
                </div>
            </div>
            <div class="p-6">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-sm font-medium text-amber-600">${work.category}</span>
                    <span class="text-xs text-gray-500">${work.readCount} 阅读</span>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2">${work.title}</h3>
                <p class="text-gray-600 text-sm mb-4 line-clamp-2">${work.description}</p>
                
                <div class="mb-4">
                    <div class="flex justify-between text-xs text-gray-500 mb-1">
                        <span>阅读进度</span>
                        <span>${progress}/${work.totalChapters} 章</span>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-2">
                        <div class="bg-amber-500 h-2 rounded-full transition-all duration-300" style="width: ${progressPercentage}%"></div>
                    </div>
                </div>
                
                <div class="flex flex-wrap gap-1 mb-4">
                    ${work.tags.map(tag => `<span class="px-2 py-1 text-xs bg-gray-100 text-gray-600 rounded-full">${tag}</span>`).join('')}
                </div>
                
                <div class="flex gap-2">
                    <button class="flex-1 bg-amber-500 text-white py-2 px-4 rounded-lg hover:bg-amber-600 transition-colors duration-200" onclick="window.location.href='works.html?id=${work.id}'">
                        开始阅读
                    </button>
                    <button class="px-4 py-2 border border-amber-500 text-amber-500 rounded-lg hover:bg-amber-50 transition-colors duration-200" onclick="platform.showDonationModal()">
                        打赏
                    </button>
                </div>
            </div>
        `;
        
        return card;
    }

    showDonationModal() {
        const modal = document.getElementById('donationModal');
        modal.style.display = 'flex';
        
        // 动画显示
        anime({
            targets: modal.querySelector('.modal-content'),
            scale: [0.8, 1],
            opacity: [0, 1],
            duration: 300,
            easing: 'easeOutQuad'
        });
    }

    selectDonationAmount(amount) {
        document.querySelectorAll('.amount-btn').forEach(btn => {
            btn.classList.remove('selected');
        });
        
        if (amount) {
            document.querySelector(`[data-amount="${amount}"]`).classList.add('selected');
        }
        
        document.getElementById('customAmount').value = amount || '';
    }

    processDonation() {
        const customAmount = document.getElementById('customAmount').value;
        const message = document.getElementById('donationMessage').value;
        const name = document.getElementById('donorName').value || '匿名用户';
        
        const amount = parseFloat(customAmount) || 0;
        
        if (amount <= 0) {
            alert('请输入有效的打赏金额');
            return;
        }
        
        // 模拟打赏处理
        this.donationData.totalAmount += amount;
        this.donationData.totalSupporters += 1;
        
        // 添加到最近打赏记录
        this.donationData.recentDonations.unshift({
            name: name,
            amount: amount,
            message: message,
            date: new Date().toISOString().split('T')[0]
        });
        
        // 保持最近记录数量
        if (this.donationData.recentDonations.length > 5) {
            this.donationData.recentDonations.pop();
        }
        
        this.updateDonationStats();
        
        // 关闭模态框
        document.getElementById('donationModal').style.display = 'none';
        
        // 显示感谢信息
        this.showThankYouMessage(name, amount);
        
        // 重置表单
        document.getElementById('customAmount').value = '';
        document.getElementById('donationMessage').value = '';
        document.getElementById('donorName').value = '';
    }

    showThankYouMessage(name, amount) {
        const thankYouModal = document.createElement('div');
        thankYouModal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        thankYouModal.innerHTML = `
            <div class="bg-white rounded-lg p-8 max-w-md mx-4 text-center">
                <div class="text-6xl mb-4">🙏</div>
                <h3 class="text-2xl font-bold text-gray-900 mb-2">感谢您的支持！</h3>
                <p class="text-gray-600 mb-4">${name}，感谢您的 ¥${amount} 打赏支持！</p>
                <p class="text-sm text-gray-500 mb-6">您的支持是我创作的最大动力</p>
                <button class="bg-amber-500 text-white px-6 py-2 rounded-lg hover:bg-amber-600 transition-colors" onclick="this.parentElement.parentElement.remove()">
                    关闭
                </button>
            </div>
        `;
        
        document.body.appendChild(thankYouModal);
        
        // 3秒后自动关闭
        setTimeout(() => {
            if (thankYouModal.parentElement) {
                thankYouModal.remove();
            }
        }, 3000);
    }

    updateDonationStats() {
        const totalAmountEl = document.getElementById('totalAmount');
        const totalSupportersEl = document.getElementById('totalSupporters');
        const monthlyAmountEl = document.getElementById('monthlyAmount');
        
        if (totalAmountEl) totalAmountEl.textContent = `¥${this.donationData.totalAmount}`;
        if (totalSupportersEl) totalSupportersEl.textContent = this.donationData.totalSupporters;
        if (monthlyAmountEl) monthlyAmountEl.textContent = `¥${this.donationData.monthlyAmount}`;
        
        // 更新最近打赏列表
        const recentList = document.getElementById('recentDonations');
        if (recentList) {
            recentList.innerHTML = '';
            this.donationData.recentDonations.forEach(donation => {
                const item = document.createElement('div');
                item.className = 'flex items-center justify-between p-3 bg-white rounded-lg shadow-sm';
                item.innerHTML = `
                    <div>
                        <div class="font-medium text-gray-900">${donation.name}</div>
                        <div class="text-sm text-gray-500">${donation.message}</div>
                    </div>
                    <div class="text-right">
                        <div class="font-bold text-amber-600">¥${donation.amount}</div>
                        <div class="text-xs text-gray-500">${donation.date}</div>
                    </div>
                `;
                recentList.appendChild(item);
            });
        }
    }

    updateReadingProgress(workId, chapter) {
        this.readingProgress[workId] = chapter;
        localStorage.setItem('readingProgress', JSON.stringify(this.readingProgress));
        this.loadWorks(); // 重新加载以更新进度显示
    }
}

// 初始化平台
let platform;
document.addEventListener('DOMContentLoaded', () => {
    platform = new CreativePlatform();
});